package com.banksystem.api.presentation.rest;

import com.banksystem.api.domain.model.EnquiryUser;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * The operator behind the current request, from the JWT claims JwtAuthFilter
 * put on it.
 *
 * <p>Stands in for the legacy's {@code receivedMsg.<service>.userId} plus its
 * stuser read (cbbranch2.c:5765-5788): login already resolved the profile, so
 * the authority string rides in the token rather than being re-read per call.
 */
@Component
public class CallerResolver {

    @SuppressWarnings("unchecked")
    public EnquiryUser resolve(HttpServletRequest request) {
        Object raw = request.getAttribute("jwtClaims");
        if (!(raw instanceof Map)) {
            return EnquiryUser.anonymous();
        }
        Map<String, Object> claims = (Map<String, Object>) raw;
        // The C concatenates authorityLevel + authorityLevel2 into one ~NN
        // string before every strstr("~NN") check.
        String authority = str(claims.get("authorityLevel")) + str(claims.get("authorityLevel2"));
        return new EnquiryUser(str(claims.get("sub")), authority);
    }

    private static String str(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
