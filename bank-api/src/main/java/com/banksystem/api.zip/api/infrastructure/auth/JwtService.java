package com.banksystem.api.infrastructure.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Minimal, dependency-free HS256 JWT (JDK HMAC + the Jackson already on the
 * classpath) — the archival build cannot reach Maven Central, so no jjwt / Spring
 * Security is added. Issued on a successful login and verified by
 * {@link JwtAuthFilter} on every protected /api/** call. This is authentication
 * only; per-authority authorization is intentionally left for later (LDAP TBD).
 */
@Component
public class JwtService {

    private static final Base64.Encoder B64 = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64D = Base64.getUrlDecoder();
    private static final byte[] HEADER =
            B64.encodeToString("{\"alg\":\"HS256\",\"typ\":\"JWT\"}".getBytes(StandardCharsets.UTF_8))
                    .getBytes(StandardCharsets.UTF_8);

    private final ObjectMapper mapper = new ObjectMapper();
    private final byte[] secret;
    private final long ttlSeconds;

    public JwtService(
            @Value("${bank.jwt.secret:}") String secret,
            @Value("${bank.jwt.ttl-seconds:3600}") long ttlSeconds) {
        // A blank secret (unset) falls back to a fixed dev key; set bank.jwt.secret
        // (>= 32 chars) via env/config in any real deployment.
        String key = secret == null || secret.isBlank()
                ? "dev-only-change-me-bank-static-data-jwt-hs256-secret-key"
                : secret;
        this.secret = key.getBytes(StandardCharsets.UTF_8);
        this.ttlSeconds = ttlSeconds;
    }

    /** Issues a signed token for the operator with the given claims. */
    public String issue(String subject, Map<String, String> claims) {
        try {
            Map<String, Object> payload = new LinkedHashMap<>(claims);
            long now = Instant.now().getEpochSecond();
            payload.put("sub", subject);
            payload.put("iat", now);
            payload.put("exp", now + ttlSeconds);
            String header = new String(HEADER, StandardCharsets.UTF_8);
            String body = B64.encodeToString(mapper.writeValueAsBytes(payload));
            String signingInput = header + "." + body;
            return signingInput + "." + B64.encodeToString(hmac(signingInput));
        } catch (Exception e) {
            throw new JwtException("could not issue token", e);
        }
    }

    /** Verifies signature + expiry and returns the claims, or throws {@link JwtException}. */
    public Map<String, Object> verify(String token) {
        String[] parts = token.split("\\.");
        if (parts.length != 3) {
            throw new JwtException("malformed token");
        }
        byte[] expected = hmac(parts[0] + "." + parts[1]);
        if (!MessageDigest.isEqual(expected, B64D.decode(parts[2]))) {
            throw new JwtException("bad signature");
        }
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> payload = mapper.readValue(B64D.decode(parts[1]), Map.class);
            long exp = ((Number) payload.getOrDefault("exp", 0L)).longValue();
            if (Instant.now().getEpochSecond() >= exp) {
                throw new JwtException("token expired");
            }
            return payload;
        } catch (JwtException e) {
            throw e;
        } catch (Exception e) {
            throw new JwtException("unreadable token", e);
        }
    }

    private byte[] hmac(String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new JwtException("HMAC failure", e);
        }
    }

    /** Signals an invalid/expired/unparseable token. */
    public static class JwtException extends RuntimeException {
        public JwtException(String message) {
            super(message);
        }

        public JwtException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
