package com.banksystem.api.infrastructure.auth;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Set;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Requires a valid Bearer JWT on every /api/** request except /api/login (which
 * issues the token). Reference-data /api/codes is now loaded only after login
 * (with a token), so it is protected too. Non-/api paths (the packaged UI) and
 * CORS preflight are skipped. Authentication only — no per-authority checks yet.
 */
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private static final Set<String> ALLOWED_ORIGINS =
            Set.of("http://localhost:5173", "http://localhost:5199");

    private final JwtService jwt;

    public JwtAuthFilter(JwtService jwt) {
        this.jwt = jwt;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true; // CORS preflight — handled by CorsConfig
        }
        String path = request.getRequestURI();
        if (!path.startsWith("/api/")) {
            return true; // static UI assets
        }
        return path.equals("/api/login");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
            FilterChain chain) throws ServletException, IOException {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            unauthorized(request, response, "Missing bearer token");
            return;
        }
        try {
            request.setAttribute("jwtClaims", jwt.verify(header.substring(7)));
        } catch (JwtService.JwtException e) {
            unauthorized(request, response, "Invalid or expired token");
            return;
        }
        chain.doFilter(request, response);
    }

    private void unauthorized(HttpServletRequest request, HttpServletResponse response, String message)
            throws IOException {
        // Echo the CORS origin so the browser surfaces the 401 (this filter runs
        // before Spring MVC's CORS handling, which would otherwise be skipped).
        String origin = request.getHeader("Origin");
        if (origin != null && ALLOWED_ORIGINS.contains(origin)) {
            response.setHeader("Access-Control-Allow-Origin", origin);
        }
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\":\"" + message + "\"}");
    }
}
