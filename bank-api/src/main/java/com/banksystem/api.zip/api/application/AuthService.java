package com.banksystem.api.application;

import com.banksystem.api.domain.model.LoginResult;
import com.banksystem.api.domain.model.SessionInfo;
import com.banksystem.api.domain.repository.UserProfileRepository;
import com.banksystem.api.domain.repository.UserProfileRepository.UserProfile;
import java.time.LocalDate;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import org.springframework.stereotype.Service;

/**
 * Logon use case — a faithful port of legacy service 00 (cblogin.c
 * processLoginRequest / staticData.frm cmdOk_Click). It reproduces the original
 * stuser-based ladder (no LDAP): look the operator up, gate on liveStatus, check
 * the password, then enforce the 30-day password age. Status codes/remarks match
 * resMsgLogin so the UI messages stay faithful to the VB6 client.
 *
 * <p>Runs against {@link UserProfileRepository} — mock fixtures now, the real
 * stuser view later — so the same logic serves both once the tables are
 * accessible. Deferred until the login tables are <i>writable</i> (they are not
 * yet): the security-log write, retry → lock persistence, single-session /
 * already-logged-in (108) tracking, and last-login stamp — all of which the
 * legacy server wrote back to stuser/stseclog.
 */
@Service
public class AuthService {

    private static final DateTimeFormatter YMD = DateTimeFormatter.ofPattern("yyyyMMdd");
    /** Legacy: password older than 30 days is expired (cblogin.c:405). */
    private static final long MAX_PASSWORD_AGE_DAYS = 30;

    private final UserProfileRepository profiles;

    public AuthService(UserProfileRepository profiles) {
        this.profiles = profiles;
    }

    public LoginResult login(String rawUserId, String password, String homeBranch) {
        String userId = rawUserId == null ? "" : rawUserId.trim().toUpperCase();
        if (userId.isEmpty() || password == null || password.isEmpty()) {
            return LoginResult.failure("102", "Invalid User Id");
        }

        // Branch permission flags key on the login request's homeBranch, not the
        // user's own branch (cblogin.c:233); blank => fail closed downstream.
        String branch = homeBranch == null ? "" : homeBranch.trim().toUpperCase();
        UserProfile user = profiles.findByUserId(userId, branch).orElse(null);
        if (user == null) {
            return LoginResult.failure("102", "UserId does not exist. Please contact Support");
        }

        // liveStatus gates come before the password check (cblogin.c order).
        if ("2".equals(user.liveStatus())) {
            return LoginResult.failure("104", "User Account is locked. Call HO to activate");
        }
        if ("3".equals(user.liveStatus())) {
            return LoginResult.failure("105", "Your Account has been closed");
        }

        // Credential check. Case-sensitive, like the legacy strncmp on the
        // (crypt-ed) password. NOTE: the real stuser stores a crypt hash — the DB
        // path must hash the entered password first (legacy getCryptPassword).
        if (!user.password().equals(password)) {
            return LoginResult.failure("103", "Invalid Password. Password is case sensitive");
        }

        // Password matched.
        if ("0".equals(user.liveStatus())) {
            return LoginResult.failure("101", "Please change your password");
        }
        if (!isSystemUser(user) && isPasswordExpired(user.lastChangeDate())) {
            return LoginResult.failure("107", "Your password has expired. Please change it");
        }

        // Token is attached by the controller (JWT lives in the web layer).
        return new LoginResult("000", "Login successful", session(user), null);
    }

    /** Authority code ~99 marks system/installation users, exempt from expiry (cblogin.c:389). */
    private static boolean isSystemUser(UserProfile p) {
        return (p.authorityLevel() + p.authorityLevel2()).contains("~99");
    }

    /** True when lastChangeDate is a valid YYYYMMDD more than 30 days ago; blank/invalid = not expired. */
    private static boolean isPasswordExpired(String lastChangeDate) {
        if (lastChangeDate == null || lastChangeDate.isBlank()) {
            return false;
        }
        try {
            LocalDate changed = LocalDate.parse(lastChangeDate.trim(), YMD);
            return ChronoUnit.DAYS.between(changed, LocalDate.now()) > MAX_PASSWORD_AGE_DAYS;
        } catch (RuntimeException e) {
            return false; // mirrors the legacy dateErr fallback (daysBetween = 0)
        }
    }

    private SessionInfo session(UserProfile p) {
        LocalDate today = LocalDate.now();
        String gregorian = today.format(YMD);
        String hijri = HijrahDate.from(today).format(YMD);
        return new SessionInfo(
                p.userId(), p.userName(), p.branchCode(),
                p.authorityLevel(), p.authorityLevel2(),
                p.langPref(), gregorian, hijri, gregorian,
                p.nameSearchAllowed(), "0900");
    }
}
