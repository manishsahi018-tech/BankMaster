package com.banksystem.api.infrastructure.persistence.jdbc;

import com.banksystem.api.application.BadRequestException;
import com.banksystem.api.domain.model.BmForms;
import com.banksystem.api.domain.model.CustUpdateHistoryEntry;
import com.banksystem.api.domain.model.CustomerProfile;
import com.banksystem.api.domain.model.CustomerSearchCriteria;
import com.banksystem.api.domain.model.CustomerSummary;
import com.banksystem.api.domain.model.EssentialDocuments;
import com.banksystem.api.domain.model.HeirEntry;
import com.banksystem.api.domain.model.IdDocument;
import com.banksystem.api.domain.model.JointHolderDetail;
import com.banksystem.api.domain.model.JointHolderEntry;
import com.banksystem.api.domain.model.JuristicAccountInfo;
import com.banksystem.api.domain.model.OpenUpdateInfo;
import com.banksystem.api.domain.model.OwnerDetail;
import com.banksystem.api.domain.model.OwnerEntry;
import com.banksystem.api.domain.model.PartyDetail;
import com.banksystem.api.domain.model.ReferenceEntry;
import com.banksystem.api.domain.repository.CustomerRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.DataAccessException;
import com.banksystem.api.domain.model.SearchScan;
import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * Customer enquiries from the Denodo views of the archival schema
 * (QUERY-SPECS.md §1 customer search, §2 update history, §22 related
 * parties; legacy cbbranch.c processSearchRequest, cbbranch2.c
 * processCustomerHistory, cbsama.c heir/joint/reference/owner scans).
 *
 * Denodo VQL over Hive is SQL-92-ish: no LIMIT (FETCH FIRST n ROWS ONLY),
 * SUBSTR is 1-based, CONCAT instead of ||. Anything beyond plain SQL-92
 * (language picking, conditional blanking, status labels) happens in the
 * row mappers.
 */
@Repository
@Profile("denodo")
public class JdbcCustomerRepository implements CustomerRepository {

    /**
     * Search scans are bounded by TIME, not by row count — exactly as the C is.
     * processSearchRequest arms alarm(searchTimeOut) before the loop
     * (cbbranch.c:1728-1730) and checks the flag once per row (:1742); on expiry
     * it flushes the rows already read and sets incompleteFlag='1' (:1746-1755).
     * Its only row cap (:1735-1740) is commented out. SEARCHTIME=30 in the
     * production cbcmssrv.cfg; override with bank.archival-db.search-timeout-seconds.
     */
    private final Duration searchTimeout;


    private static final Logger log = LoggerFactory.getLogger(JdbcCustomerRepository.class);

    private static final String SEARCH_COLUMNS = """
            SELECT custNo, idType, idNo, telHomeNo, telHomeExt,
                   aFirstName, a2ndName, aLastName, eFirstName, e2ndName, eLastName,
                   aShortName, eShortName, aOrgShortName, eOrgShortName,
                   custType, preferredLang, branchCode, samaMainCategory, samaSubCategory
            FROM   stcusttab
            WHERE  BankingDate = :bankingDate
            """;

    /** stcusttab point read — column list matches CustomerProfile. */
    private static final String PROFILE_SQL = """
            SELECT custNo, custType, samaMainCategory, samaSubCategory, branchCode,
                   nationality, preferredLang, idType, idNo, idIssuedAt,
                   idIssueDateH, idIssueDateG, idExpiryDateH, idExpiryDateG,
                   aFirstName, a2ndName, a3rdName, aLastName, aShortName,
                   eFirstName, e2ndName, e3rdName, eLastName, eShortName,
                   aOrgName1, aOrgShortName, eOrgName1, eOrgShortName,
                   crNo, crIssuedAt, crIssueDateH, crIssueDateG,
                   dobDateH, dobDateG, sexCode, marritalStatus, businessType,
                   address1, address2, poBox, cityName, zipCode, country,
                   telHomeNo, telOffNo, mobileNo, eMail, custOpenDate, relationshipManager,
                   altBranchCode, titleCode, certificateOfBirthNo, referenceReqdFor,
                   idDateType, dobDateType, noOfDependents, residentStatus,
                   addressType, gprsNo, unitNo,
                   passportNo, hafizaNo, samaAuthNo, familyRegnNo, succDeedNo,
                   telOffAreaCode, telOffExt, telHomeAreaCode, telHomeExt,
                   faxAreaCode, faxNo, faxExt, pagerNo,
                   lastUpdateUser, lastUpdateDateTime, vipCode, visaNo,
                   aOrgName2, eOrgName2, orgAlphaSearchCode, purposeOfAccount,
                   govtShareHoldingPerc, saudiShareHoldingPerc, foreignShareHoldingPerc,
                   crIssueDateType, licenseNo, approvalRefNo,
                   contractNo, diplomaticCardNo
            FROM   stcusttab
            WHERE  BankingDate = :bankingDate
              AND  custNo = :custNo
            """;

    /**
     * The five ID rows of frmIndividualSaudi (cbsaudi.c:2809-2872). idCategory
     * 'C' selects the customer's own documents ('S' rows belong to signatories).
     * Ordered so the screen's row order is stable regardless of storage order.
     */
    private static final String ID_DOCUMENTS_SQL = """
            SELECT idType, idNo, idIssuedAt, idDateType, iqamaType,
                   idIssueDateH, idIssueDateG, idExpiryDateH, idExpiryDateG,
                   idRefName
            FROM   stidtab
            WHERE  BankingDate = :bankingDate
              AND  custNo = :custNo AND idCategory = 'C'
            ORDER  BY idType
            """;

    /**
     * Open/Update frames — getCustomerOpenUpdateInfo (cbothers.c:3198-3397).
     * stcustlog index 3 is (custNo, lastUpdateDateTime); the C walks it twice:
     *
     *   LATEST  (:3220-3243) seed custNo + "999999999999999", ISGREAT then one
     *           ISPREV  -> userId = Update Maker, branchCode = Update Branch.
     *   EARLIEST(:3301-3397) seed custNo + 14 spaces, ISGTEQ then one ISNEXT
     *           -> userId = Open Maker, branchCode = Branch Opened,
     *              lastUpdateUser = Open Supervisor.
     *
     * The C seeds the earliest read with SPACES, so rows carrying a blank
     * lastUpdateDateTime are the intended target of that read, not noise —
     * they are deliberately NOT filtered out.
     *
     * The per-year archive files (custlog2000…) the C loops over collapse to
     * this one view in the archival schema (QUERY-SPECS cross-cutting #3), so
     * the loop becomes a single ordered read.
     */
    private static final String OPEN_UPDATE_SQL = """
            SELECT branchCode, userId, lastUpdateUser
            FROM   stcustlog
            WHERE  BankingDate = :bankingDate
              AND  custNo = :custNo
            ORDER  BY lastUpdateDateTime %s
            FETCH  FIRST 1 ROWS ONLY
            """;

    /**
     * Same shape from the stcustlog snapshot (legacy service 11
     * requestType 01). Column-name discrepancies vs stcusttab, per the
     * generated schema files (schema wins over the spec):
     * stcustlog spells "maritalStatus" (one 'r') where stcusttab has
     * "marritalStatus"; the customer's own branch lives in custBranchCode
     * (stcustlog.branchCode is the transaction branch of the update).
     */
    private static final String PROFILE_ASOF_SQL = """
            SELECT custNo, custType, samaMainCategory, samaSubCategory,
                   custBranchCode AS branchCode,
                   nationality, preferredLang, idType, idNo, idIssuedAt,
                   idIssueDateH, idIssueDateG, idExpiryDateH, idExpiryDateG,
                   aFirstName, a2ndName, a3rdName, aLastName, aShortName,
                   eFirstName, e2ndName, e3rdName, eLastName, eShortName,
                   aOrgName1, aOrgShortName, eOrgName1, eOrgShortName,
                   crNo, crIssuedAt, crIssueDateH, crIssueDateG,
                   dobDateH, dobDateG, sexCode, maritalStatus AS marritalStatus, businessType,
                   address1, address2, poBox, cityName, zipCode, country,
                   telHomeNo, telOffNo, mobileNo, eMail, custOpenDate, relationshipManager,
                   altBranchCode, titleCode, certificateOfBirthNo, referenceReqdFor,
                   idDateType, dobDateType, noOfDependents, residentStatus,
                   addressType, gprsNo, unitNo,
                   passportNo, hafizaNo, samaAuthNo, familyRegnNo, succDeedNo,
                   telOffAreaCode, telOffExt, telHomeAreaCode, telHomeExt,
                   faxAreaCode, faxNo, faxExt, pagerNo,
                   lastUpdateUser, lastUpdateDateTime, vipCode, visaNo,
                   aOrgName2, eOrgName2, orgAlphaSearchCode, purposeOfAccount,
                   govtShareHoldingPerc, saudiShareHoldingPerc, foreignShareHoldingPerc,
                   crIssueDateType, licenseNo, approvalRefNo,
                   contractNo, diplomaticCardNo
            FROM   stcustlog
            WHERE  BankingDate = :bankingDate
              AND  custNo = :custNo
              AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
            """;

    /** Column labels shared by PROFILE_SQL / PROFILE_ASOF_SQL. */
    private static final String[] PROFILE_COLUMNS = {
            "custNo", "custType", "samaMainCategory", "samaSubCategory", "branchCode",
            "nationality", "preferredLang", "idType", "idNo", "idIssuedAt",
            "idIssueDateH", "idIssueDateG", "idExpiryDateH", "idExpiryDateG",
            "aFirstName", "a2ndName", "a3rdName", "aLastName", "aShortName",
            "eFirstName", "e2ndName", "e3rdName", "eLastName", "eShortName",
            "aOrgName1", "aOrgShortName", "eOrgName1", "eOrgShortName",
            "crNo", "crIssuedAt", "crIssueDateH", "crIssueDateG",
            "dobDateH", "dobDateG", "sexCode", "marritalStatus", "businessType",
            "address1", "address2", "poBox", "cityName", "zipCode", "country",
            "telHomeNo", "telOffNo", "mobileNo", "eMail", "custOpenDate",
            "relationshipManager",
            "altBranchCode", "titleCode", "certificateOfBirthNo", "referenceReqdFor",
            "idDateType", "dobDateType", "noOfDependents", "residentStatus",
            "addressType", "gprsNo", "unitNo",
            "passportNo", "hafizaNo", "samaAuthNo", "familyRegnNo", "succDeedNo",
            "telOffAreaCode", "telOffExt", "telHomeAreaCode", "telHomeExt",
            "faxAreaCode", "faxNo", "faxExt", "pagerNo",
            "lastUpdateUser", "lastUpdateDateTime", "vipCode", "visaNo",
            "aOrgName2", "eOrgName2", "orgAlphaSearchCode", "purposeOfAccount",
            "govtShareHoldingPerc", "saudiShareHoldingPerc", "foreignShareHoldingPerc",
            "crIssueDateType", "licenseNo", "approvalRefNo",
            "contractNo", "diplomaticCardNo"};

    /** Raw column values keyed by label — the as-of path overlays
     *  stidlog/staddrlog values into this map before the record is built. */
    private static final RowMapper<Map<String, String>> PROFILE_COLUMN_MAPPER = (rs, i) -> {
        Map<String, String> m = new HashMap<>();
        for (String col : PROFILE_COLUMNS) {
            m.put(col, rs.getString(col));
        }
        return m;
    };

    private static final RowMapper<CustomerProfile> PROFILE_MAPPER =
            (rs, i) -> toProfile(PROFILE_COLUMN_MAPPER.mapRow(rs, i));

    private static CustomerProfile toProfile(Map<String, String> m) {
        return new CustomerProfile(
                m.get("custNo"), m.get("custType"),
                m.get("samaMainCategory"), m.get("samaSubCategory"),
                m.get("branchCode"), m.get("nationality"),
                m.get("preferredLang"), m.get("idType"),
                m.get("idNo"), m.get("idIssuedAt"),
                BmForms.actualDate(m.get("idIssueDateH")),
                BmForms.actualDate(m.get("idIssueDateG")),
                BmForms.actualDate(m.get("idExpiryDateH")),
                BmForms.actualDate(m.get("idExpiryDateG")),
                m.get("aFirstName"), m.get("a2ndName"),
                m.get("a3rdName"), m.get("aLastName"), m.get("aShortName"),
                m.get("eFirstName"), m.get("e2ndName"),
                m.get("e3rdName"), m.get("eLastName"), m.get("eShortName"),
                m.get("aOrgName1"), m.get("aOrgShortName"),
                m.get("eOrgName1"), m.get("eOrgShortName"),
                m.get("crNo"), m.get("crIssuedAt"),
                BmForms.actualDate(m.get("crIssueDateH")),
                BmForms.actualDate(m.get("crIssueDateG")),
                BmForms.actualDate(m.get("dobDateH")),
                BmForms.actualDate(m.get("dobDateG")),
                m.get("sexCode"), m.get("marritalStatus"), m.get("businessType"),
                m.get("address1"), m.get("address2"), m.get("poBox"),
                m.get("cityName"), m.get("zipCode"), m.get("country"),
                m.get("telHomeNo"), m.get("telOffNo"),
                m.get("mobileNo"), m.get("eMail"),
                BmForms.actualDate(m.get("custOpenDate")),
                m.get("relationshipManager"),
                m.get("altBranchCode"), m.get("titleCode"),
                m.get("certificateOfBirthNo"), m.get("referenceReqdFor"),
                m.get("idDateType"), m.get("dobDateType"),
                m.get("noOfDependents"), m.get("residentStatus"),
                m.get("addressType"), m.get("gprsNo"), m.get("unitNo"),
                m.get("passportNo"), m.get("hafizaNo"), m.get("samaAuthNo"),
                m.get("familyRegnNo"), m.get("succDeedNo"),
                m.get("telOffAreaCode"), m.get("telOffExt"),
                m.get("telHomeAreaCode"), m.get("telHomeExt"),
                m.get("faxAreaCode"), m.get("faxNo"), m.get("faxExt"),
                m.get("pagerNo"),
                m.get("lastUpdateUser"),
                BmForms.isoToBmTimestamp(m.get("lastUpdateDateTime")),
                m.get("vipCode"), m.get("visaNo"),
                m.get("aOrgName2"), m.get("eOrgName2"),
                m.get("orgAlphaSearchCode"), m.get("purposeOfAccount"),
                m.get("govtShareHoldingPerc"), m.get("saudiShareHoldingPerc"),
                m.get("foreignShareHoldingPerc"), m.get("crIssueDateType"),
                m.get("licenseNo"), m.get("approvalRefNo"),
                m.get("contractNo"), m.get("diplomaticCardNo"),
                // filled by the point read; the as-of path leaves them empty
                List.of(), OpenUpdateInfo.empty());
    }

    private static final RowMapper<IdDocument> ID_DOCUMENT_MAPPER = (rs, i) -> new IdDocument(
            rs.getString("idType"), rs.getString("idNo"), rs.getString("idIssuedAt"),
            rs.getString("idDateType"), rs.getString("iqamaType"),
            BmForms.actualDate(rs.getString("idIssueDateH")),
            BmForms.actualDate(rs.getString("idIssueDateG")),
            BmForms.actualDate(rs.getString("idExpiryDateH")),
            BmForms.actualDate(rs.getString("idExpiryDateG")),
            rs.getString("idRefName"));

    private final NamedParameterJdbcTemplate jdbc;
    private final BankingDateProvider bankingDate;

    public JdbcCustomerRepository(
            @Qualifier("archivalJdbc") NamedParameterJdbcTemplate jdbc,
            BankingDateProvider bankingDate,
            @Value("${bank.archival-db.search-timeout-seconds:30}") long searchTimeoutSeconds) {
        this.jdbc = jdbc;
        this.bankingDate = bankingDate;
        // SEARCHTIME=30 in the production cbcmssrv.cfg (cbrouter.c:92 default,
        // :1715 reads the override).
        this.searchTimeout = Duration.ofSeconds(searchTimeoutSeconds);
    }

    // ------------------------------------------------------------------
    // §1 — customer search (service 16): first non-blank criterion wins.
    // ------------------------------------------------------------------

    @Override
    public SearchScan<CustomerSummary> search(CustomerSearchCriteria c) {
        if (hasText(c.custNo())) {
            return searchEquals("custNo", padCust(c.custNo()), false);
        }
        if (hasText(c.cardNo())) {
            // Card branch: resolve the customer via stcardtab first, then run
            // the plain custNo branch. An unknown card is an ERROR, not an
            // empty result — the C's isRead(ISEQUAL) failing with iserrno
            // 110/111 sends INTERNALERR "Invalid card number entered.. Please
            // check" and returns FAILURE (cbbranch.c:1574-1586).
            String cust = resolveCardCustomer(c.cardNo().trim())
                    .orElseThrow(() -> new BadRequestException(
                            "Invalid card number entered.. Please check"));
            return searchEquals("custNo", padCust(cust), false);
        }
        String idOrCr = hasText(c.idNo()) ? c.idNo() : c.crNo();
        if (hasText(idOrCr)) {
            // Legacy key 3 seeds idType too but never re-checks it (§1),
            // so only idNo is filtered; crNo searches the same key.
            return searchEquals("idNo", idOrCr.trim(), false);
        }
        if (hasText(c.telNo())) {
            return searchByTel(c);
        }
        if (hasText(c.firstName())) {
            return searchByFirstName(c);
        }
        if (hasText(c.secondName())) {
            return searchBySecondName(c);
        }
        if (hasText(c.lastName())) {
            return searchByLastName(c);
        }
        if (hasText(c.mainCategoryCode()) || hasText(c.subCategoryCode())) {
            // Legacy branch entry tests 4 bytes spanning BOTH category
            // fields (cbbranch.c:1705), so a sub-only input still runs the
            // category search.
            return searchByCategory(c);
        }
        if (hasText(c.branchCode())) {
            return searchEquals("branchCode", c.branchCode().trim(), false);
        }
        if (hasText(c.mobileNo())) {
            return searchEquals("mobileNo", c.mobileNo().trim(), false);
        }
        // No branch matched — the C falls off the end of the chain with an
        // empty response (never reached: CustomerService rejects empty criteria).
        return SearchScan.complete(List.of());
    }

    /**
     * Reads a scan under the legacy's search clock: rows are collected until
     * the result set ends (complete) or the deadline passes (partial, flagged).
     * Mirrors the C's per-row alarm check rather than capping the SQL.
     */
    private SearchScan<CustomerSummary> scan(String sql, Map<String, ?> params, RowMapper<CustomerSummary> mapper) {
        long deadline = System.nanoTime() + searchTimeout.toNanos();
        boolean[] cutShort = {false};
        List<CustomerSummary> rows = jdbc.query(sql,
                new MapSqlParameterSource(params)
                        .addValue("bankingDate", bankingDate.bankingDate()),
                (ResultSetExtractor<List<CustomerSummary>>) rs -> {
                    List<CustomerSummary> out = new ArrayList<>();
                    while (rs.next()) {
                        out.add(mapper.mapRow(rs, out.size()));
                        // checked per row, as the C checks searchTimeoutFlag (:1742)
                        if (System.nanoTime() >= deadline) {
                            cutShort[0] = rs.next();   // more waiting? then we were cut short
                            break;
                        }
                    }
                    return out;
                });
        if (cutShort[0]) {
            log.warn("Search could not be completed within {} seconds; returning {} rows "
                    + "with the incomplete flag set", searchTimeout.toSeconds(), rows.size());
        }
        return new SearchScan<>(rows, cutShort[0]);
    }

    private SearchScan<CustomerSummary> searchEquals(String column, String value, boolean arabicSearch) {
        String order = "custNo".equals(column) ? "custNo" : column + ", custNo";
        return scan(SEARCH_COLUMNS + """
                  AND  %s = :value
                ORDER  BY %s
                """.formatted(column, order),
                Map.of("value", value),
                summaryMapper(arabicSearch));
    }

    /**
     * Legacy card resolution: the schema file's stcardtab carries a direct
     * custNo column (size 7); §1's SUBSTR(bmAccNo, 6, 7) stays as fallback —
     * stcardtab.bmAccNo is 14 chars (actual form despite its name), so the
     * embedded customer is at positions 6..12, 1-based.
     */
    private Optional<String> resolveCardCustomer(String cardNo) {
        return jdbc.query("""
                SELECT COALESCE(NULLIF(TRIM(custNo), ''), SUBSTR(bmAccNo, 6, 7)) AS custNo
                FROM   stcardtab
                WHERE  BankingDate = :bankingDate
                  AND  cardNo = :cardNo
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "cardNo", cardNo),
                (rs, i) -> rs.getString("custNo"))
                .stream().filter(JdbcCustomerRepository::hasText).findFirst();
    }

    /**
     * Legacy key 4 seeds telHomeNo+telHomeExt into the ISGTEQ start
     * (cbbranch.c:1614-1616, isstart length 14) but the loop breaks on
     * telHomeNo only (cbbranch.c:1768-1771): when an extension is
     * supplied, rows whose extension sorts below it are skipped by the
     * key start — i.e. telHomeExt >= :telExt, not equality.
     */
    private SearchScan<CustomerSummary> searchByTel(CustomerSearchCriteria c) {
        StringBuilder sql = new StringBuilder(SEARCH_COLUMNS)
                .append("  AND  telHomeNo = :telNo\n");
        Map<String, Object> params = new HashMap<>();
        params.put("telNo", c.telNo().trim());
        if (hasText(c.telExt())) {
            sql.append("  AND  telHomeExt >= :telExt\n");
            params.put("telExt", c.telExt().trim());
        }
        sql.append("ORDER  BY telHomeNo, telHomeExt, custNo\n");
        return scan(sql.toString(), params, summaryMapper(false));
    }

    private SearchScan<CustomerSummary> searchByFirstName(CustomerSearchCriteria c) {
        String first = trimName(c.firstName());
        boolean arabic = isArabic(first);
        String fCol = arabic ? "aFirstName" : "eFirstName";
        StringBuilder sql = new StringBuilder(SEARCH_COLUMNS)
                .append("  AND  ").append(fCol).append(" LIKE CONCAT(:firstName, '%')\n");
        Map<String, Object> params = new HashMap<>();
        params.put("firstName", first);
        // Legacy continue-filters: second/last name prefixes, same language
        // columns as the index branch.
        if (hasText(c.secondName())) {
            sql.append("  AND  ").append(arabic ? "a2ndName" : "e2ndName")
                    .append(" LIKE CONCAT(:secondName, '%')\n");
            params.put("secondName", trimName(c.secondName()));
        }
        if (hasText(c.lastName())) {
            sql.append("  AND  ").append(arabic ? "aLastName" : "eLastName")
                    .append(" LIKE CONCAT(:lastName, '%')\n");
            params.put("lastName", trimName(c.lastName()));
        }
        sql.append("ORDER  BY ").append(fCol).append(", custNo\n");
        return scan(sql.toString(), params, summaryMapper(arabic));
    }

    private SearchScan<CustomerSummary> searchBySecondName(CustomerSearchCriteria c) {
        String second = trimName(c.secondName());
        boolean arabic = isArabic(second);
        String sCol = arabic ? "a2ndName" : "e2ndName";
        StringBuilder sql = new StringBuilder(SEARCH_COLUMNS)
                .append("  AND  ").append(sCol).append(" LIKE CONCAT(:secondName, '%')\n");
        Map<String, Object> params = new HashMap<>();
        params.put("secondName", second);
        if (hasText(c.lastName())) {
            sql.append("  AND  ").append(arabic ? "aLastName" : "eLastName")
                    .append(" LIKE CONCAT(:lastName, '%')\n");
            params.put("lastName", trimName(c.lastName()));
        }
        sql.append("ORDER  BY ").append(sCol).append(", custNo\n");
        return scan(sql.toString(), params, summaryMapper(arabic));
    }

    private SearchScan<CustomerSummary> searchByLastName(CustomerSearchCriteria c) {
        String last = trimName(c.lastName());
        boolean arabic = isArabic(last);
        String lCol = arabic ? "aLastName" : "eLastName";
        return scan(SEARCH_COLUMNS + """
                  AND  %s LIKE CONCAT(:lastName, '%%')
                ORDER  BY %s, custNo
                """.formatted(lCol, lCol),
                Map.of("lastName", last),
                summaryMapper(arabic));
    }

    private SearchScan<CustomerSummary> searchByCategory(CustomerSearchCriteria c) {
        // Legacy key 10 seeds samaMainCategory+samaSubCategory as 4
        // contiguous bytes AND the loop break re-compares all 4 bytes
        // (cbbranch.c:1709-1711 seed, 1846-1850 break; the request and
        // record fields are contiguous per cbserver.h reqMsgSearch and
        // stlayout.h customerInfo). BOTH parts therefore always filter:
        // a blank input part only matches rows whose stored part is
        // blank too.
        return scan(SEARCH_COLUMNS + """
                  AND  COALESCE(TRIM(samaMainCategory), '') = :mainCategory
                  AND  COALESCE(TRIM(samaSubCategory), '') = :subCategory
                ORDER  BY samaMainCategory, samaSubCategory, custNo
                """,
                Map.of("mainCategory", trim(c.mainCategoryCode()),
                        "subCategory", trim(c.subCategoryCode())),
                summaryMapper(false));
    }

    /**
     * §1 response mapping: first/second/last name from the Arabic columns
     * when the search was Arabic or preferredLang is Arabic, else English
     * (cbbranch.c:1865-1884). shortName is chosen by preferredLang ONLY —
     * the C's shortName block (cbbranch.c:1886-1919) tests
     * custTabRec.preferredLang regardless of the search language — from
     * a/eShortName for consumers vs a/eOrgShortName for commercial and
     * corporate customers, with other-language fallback when blank.
     */
    private RowMapper<CustomerSummary> summaryMapper(boolean arabicSearch) {
        return (rs, i) -> {
            boolean arabicNames = arabicSearch || prefersArabic(rs.getString("preferredLang"));
            boolean arabicShort = prefersArabic(rs.getString("preferredLang"));
            boolean corporate = isCorporate(rs.getString("custType"));
            String aShort = rs.getString(corporate ? "aOrgShortName" : "aShortName");
            String eShort = rs.getString(corporate ? "eOrgShortName" : "eShortName");
            String shortName = arabicShort ? firstNonBlank(aShort, eShort) : firstNonBlank(eShort, aShort);
            return new CustomerSummary(
                    rs.getString("custNo"), rs.getString("idType"), rs.getString("idNo"),
                    rs.getString("telHomeNo"), rs.getString("telHomeExt"),
                    rs.getString(arabicNames ? "aFirstName" : "eFirstName"),
                    rs.getString(arabicNames ? "a2ndName" : "e2ndName"),
                    rs.getString(arabicNames ? "aLastName" : "eLastName"),
                    shortName, rs.getString("branchCode"),
                    rs.getString("samaMainCategory"), rs.getString("samaSubCategory"));
        };
    }

    // ------------------------------------------------------------------
    // §2 — customer update history (service 67).
    // ------------------------------------------------------------------

    @Override
    public List<CustUpdateHistoryEntry> updateHistory(String custNo) {
        // Per-year archive files collapse to the single stcustlog view.
        // No msgType/status filter — only the custNo boundary (§2).
        // Ordering: stcustlog key 3 is custNo+lastUpdateDateTime (the C
        // blanks lastUpdateDateTime when seeding the key,
        // cbbranch2.c:1014-1019), so pending rows with a blank
        // lastUpdateDateTime sort first — hence the COALESCE.
        return jdbc.query("""
                SELECT branchCode, userId, datetime_bigdata AS dateTime, bmUpdateStatus,
                       supervisorId, lastUpdateDateTime, samaMainCategory, samaSubCategory
                FROM   stcustlog
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                ORDER  BY COALESCE(lastUpdateDateTime, '')
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> {
                    String status = trim(rs.getString("bmUpdateStatus"));
                    // Field rule: supervisorId / lastUpdateDateTime blanked
                    // while the update is still pending ('1' or '2').
                    boolean pending = "1".equals(status) || "2".equals(status);
                    return new CustUpdateHistoryEntry(
                            rs.getString("branchCode"), rs.getString("userId"),
                            BmForms.isoToBmTimestamp(rs.getString("dateTime")), statusLabel(status),
                            pending ? "" : rs.getString("supervisorId"),
                            pending ? "" : BmForms.isoToBmTimestamp(rs.getString("lastUpdateDateTime")),
                            rs.getString("samaMainCategory"), rs.getString("samaSubCategory"));
                });
    }

    // ------------------------------------------------------------------
    // Profile point reads (stcusttab / stcustlog snapshot).
    // ------------------------------------------------------------------

    @Override
    public Optional<CustomerProfile> profile(String custNo) {
        Map<String, Object> params = Map.of(
                "bankingDate", bankingDate.bankingDate(),
                "custNo", padCust(custNo));
        return jdbc.query(PROFILE_SQL, params, PROFILE_MAPPER).stream().findFirst()
                .map(p -> p.withRelated(idDocuments(params), openUpdate(params, p)));
    }

    /** The five ID rows. Absent stidtab rows are not an error — the screen
     *  falls back to the bare numbers stcusttab carries. */
    private List<IdDocument> idDocuments(Map<String, Object> params) {
        try {
            return jdbc.query(ID_DOCUMENTS_SQL, params, ID_DOCUMENT_MAPPER);
        } catch (DataAccessException e) {
            log.warn("stidtab read failed for the ID rows; falling back to the "
                    + "stcusttab numbers: {}", e.getMessage());
            return List.of();
        }
    }

    /** Earliest stcustlog row = opening details, latest = update details. */
    private OpenUpdateInfo openUpdate(Map<String, Object> params, CustomerProfile p) {
        // cbothers.c:3216-3218 — these three come from stcusttab, NOT the log:
        //   custOpenDate           <- custTabRec.custOpenDate
        //   lastUpdateSupervisorId <- custTabRec.lastUpdateUser
        //   lastUpdateDate         <- custTabRec.lastUpdateDateTime, first 8
        String openDate = p.custOpenDate();
        String updateSupervisorId = trim(p.lastUpdateUser());
        String lastUpdateDate = dateOf(p.lastUpdateDateTime());
        try {
            Map<String, String> latest = firstLog(params, "DESC");
            Map<String, String> earliest = firstLog(params, "ASC");
            return new OpenUpdateInfo(
                    openDate,
                    earliest == null ? "" : trim(earliest.get("branchCode")),
                    earliest == null ? "" : trim(earliest.get("userId")),
                    earliest == null ? "" : trim(earliest.get("lastUpdateUser")),
                    lastUpdateDate,
                    latest == null ? "" : trim(latest.get("branchCode")),
                    latest == null ? "" : trim(latest.get("userId")),
                    updateSupervisorId);
        } catch (DataAccessException e) {
            log.warn("stcustlog read failed for the open/update frames: {}", e.getMessage());
            // the C tolerates both log reads failing and still returns the
            // stcusttab-sourced fields
            return new OpenUpdateInfo(openDate, "", "", "", lastUpdateDate, "", "", updateSupervisorId);
        }
    }

    private Map<String, String> firstLog(Map<String, Object> params, String direction) {
        return jdbc.query(OPEN_UPDATE_SQL.formatted(direction), params, (rs, i) -> {
            Map<String, String> m = new HashMap<>();
            for (String c : new String[]{"branchCode", "userId", "lastUpdateUser"}) {
                m.put(c, rs.getString(c));
            }
            return m;
        }).stream().findFirst().orElse(null);
    }

    /** stcustlog stamps carry a time; the audit frames show only the date. */
    private static String dateOf(String timestamp) {
        String t = BmForms.isoToBmTimestamp(trim(timestamp));
        return t.length() >= 8 ? t.substring(0, 8) : t;
    }

    @Override
    public Optional<CustomerProfile> profileAsOf(String custNo, String dateTime) {
        // The UI's "View Details" passes the history row's stcustlog
        // dateTime (event timestamp), not lastUpdateDateTime. The legacy
        // echoes the same 14-char value the history list sent and reads on it
        // byte-for-byte — strncpy(custLogRec.dateTime, ...dateTime, 14) then
        // readCustLogFile(ISEQUAL) (cbjuristic.c:2055-2057); the companion log
        // reads copy the same 14 bytes verbatim (cbsaudi.c:3020-3022).
        //
        // BOUND IN BOTH FORMS, and it has to be. The list side does NOT hand
        // the UI what the column holds: updateHistory maps the column through
        // BmForms.isoToBmTimestamp, which is a no-op on a 14-char string but
        // rewrites an ISO timestamp to YYYYMMDDHH24MISS. So the round trip only
        // closes when datetime_bigdata is a string — when the view types it as
        // a timestamp, the list normalises, the UI sends the normalised value
        // back, this predicate compares it raw, matches nothing, and the
        // drill-down 404s "History record not found" on a row that demonstrably
        // exists (it came out of this very table). Binding raw alone was the
        // earlier fix for the mirror-image bug and is still right for a string
        // column; the OR keeps that and covers the timestamp case, and can only
        // ever match more rows than before, never fewer.
        //
        // The same pairing is applied to the stidlog / staddrlog overlays below
        // and to JdbcAccountRepository.snapshot, which has the identical shape.
        Map<String, Object> params = Map.of(
                "bankingDate", bankingDate.bankingDate(),
                "custNo", padCust(custNo),
                "dateTime", trim(dateTime), "dateTimeIso", BmForms.bmToIso(trim(dateTime)));
        Map<String, String> snapshot = jdbc.query(PROFILE_ASOF_SQL, params, PROFILE_COLUMN_MAPPER)
                .stream().findFirst().orElse(null);
        if (snapshot == null) {
            return Optional.empty();
        }
        // Legacy processIndividual*PendingDetail overlays the stcustlog
        // snapshot with its stidlog / staddrlog companion rows, which are
        // keyed by the log row's OWN branchCode (transaction branch) +
        // userId + dateTime (cbsaudi.c:3020-3026, 3186-3195). The profile
        // SQL exposes custBranchCode, so fetch that key separately.
        Map<String, Object> logKey = jdbc.query("""
                SELECT branchCode, userId, datetime_bigdata AS dateTime
                FROM   stcustlog
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
                """,
                params,
                (rs, i) -> {
                    Map<String, Object> k = new HashMap<>();
                    k.put("bankingDate", bankingDate.bankingDate());
                    k.put("branchCode", rs.getString("branchCode"));
                    k.put("userId", rs.getString("userId"));
                    String bm = BmForms.isoToBmTimestamp(rs.getString("dateTime"));
                    k.put("dateTime", bm);
                    k.put("dateTimeIso", BmForms.bmToIso(bm));
                    return k;
                })
                .stream().findFirst().orElse(null);
        if (logKey != null) {
            overlayIdLog(snapshot, logKey);
            overlayAddrLog(snapshot, logKey);
        }
        return Optional.of(toProfile(snapshot));
    }

    /**
     * cbsaudi.c:3029-3095: the as-of detail scans stidlog for the custlog
     * row's key, keeps idCategory 'C' (customer's own IDs) rows only and
     * overlays the per-idType ID buckets; the stcustlog snapshot fields
     * are used only when no idlog row exists (cbsaudi.c:3096-3158) — here
     * that fallback is simply "leave the snapshot untouched". Ported as
     * practical for this profile shape: the row matching the snapshot's
     * idType feeds the generic ID block, and an idType 'C' row feeds the
     * CR block (mirroring the juristic mapping, cbjuristic.c:3097-3106).
     */
    private void overlayIdLog(Map<String, String> snapshot, Map<String, Object> logKey) {
        try {
            List<Map<String, String>> rows = jdbc.query("""
                    SELECT idType, idNo, idIssuedAt, idIssueDateH, idIssueDateG,
                           idExpiryDateH, idExpiryDateG
                    FROM   stidlog
                    WHERE  BankingDate = :bankingDate
                      AND  branchCode = :branchCode
                      AND  userId = :userId
                      AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
                      AND  idCategory = 'C'
                    """,
                    logKey,
                    (rs, i) -> {
                        Map<String, String> r = new HashMap<>();
                        for (String col : new String[] {"idType", "idNo", "idIssuedAt",
                                "idIssueDateH", "idIssueDateG", "idExpiryDateH", "idExpiryDateG"}) {
                            r.put(col, rs.getString(col));
                        }
                        return r;
                    });
            for (Map<String, String> r : rows) {
                String idType = trim(r.get("idType"));
                if (!idType.isEmpty() && idType.equals(trim(snapshot.get("idType")))) {
                    snapshot.put("idNo", r.get("idNo"));
                    snapshot.put("idIssuedAt", r.get("idIssuedAt"));
                    snapshot.put("idIssueDateH", r.get("idIssueDateH"));
                    snapshot.put("idIssueDateG", r.get("idIssueDateG"));
                    snapshot.put("idExpiryDateH", r.get("idExpiryDateH"));
                    snapshot.put("idExpiryDateG", r.get("idExpiryDateG"));
                }
                if ("C".equals(idType)) {
                    snapshot.put("crNo", r.get("idNo"));
                    snapshot.put("crIssuedAt", r.get("idIssuedAt"));
                    snapshot.put("crIssueDateH", r.get("idIssueDateH"));
                    snapshot.put("crIssueDateG", r.get("idIssueDateG"));
                }
            }
        } catch (DataAccessException e) {
            log.warn("stidlog overlay unavailable for as-of profile; keeping stcustlog values", e);
        }
    }

    /**
     * cbsaudi.c:3186-3245: the local address/phone block comes from the
     * staddrlog row (addressType '00', addressNo '0000') keyed like the
     * custlog row; the stcustlog snapshot address is only the fallback
     * (the C logs "taking the address info from stcustlog" on a read
     * miss). The whole block is replaced wholesale when the row exists,
     * exactly as the C strncpy block does.
     */
    private void overlayAddrLog(Map<String, String> snapshot, Map<String, Object> logKey) {
        try {
            jdbc.query("""
                    SELECT address1, address2, poBox, cityName, zipCode, country,
                           telHomeNo, telOffNo, mobileNo, eMail
                    FROM   staddrlog
                    WHERE  BankingDate = :bankingDate
                      AND  branchCode = :branchCode
                      AND  userId = :userId
                      AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
                      AND  addressType = '00' AND addressNo = '0000'
                    """,
                    logKey,
                    (rs, i) -> {
                        Map<String, String> r = new HashMap<>();
                        for (String col : new String[] {"address1", "address2", "poBox",
                                "cityName", "zipCode", "country", "telHomeNo", "telOffNo",
                                "mobileNo", "eMail"}) {
                            r.put(col, rs.getString(col));
                        }
                        return r;
                    })
                    .stream().findFirst().ifPresent(snapshot::putAll);
        } catch (DataAccessException e) {
            log.warn("staddrlog overlay unavailable for as-of profile; keeping stcustlog values", e);
        }
    }

    // ------------------------------------------------------------------
    // Juristic page 2 (frmJuristicAccountInfo).
    // ------------------------------------------------------------------

    @Override
    public Optional<JuristicAccountInfo> juristicAccountInfo(String custNo) {
        // No data-side category gate: legacy processJuristicDetail
        // (cbjuristic.c:2968-3320) serves whatever customer it is asked
        // for — screen routing by custType/category is the client's job.
        Map<String, Object> params = Map.of(
                "bankingDate", bankingDate.bankingDate(),
                "custNo", padCust(custNo));
        return jdbc.query("""
                SELECT custNo, branchCode, createdUserId, createdDateTime,
                       signatureNature, internetBankAcc, custAdviceFlag, updatedForSama,
                       relationshipManager, generalMemo, marketingMemo, accFreezingGracePeriod
                FROM   stcusttab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                """,
                params,
                (rs, i) -> new String[] {
                        rs.getString("custNo"), rs.getString("branchCode"),
                        rs.getString("createdUserId"),
                        BmForms.isoToBmTimestamp(rs.getString("createdDateTime")),
                        rs.getString("signatureNature"), rs.getString("internetBankAcc"),
                        rs.getString("custAdviceFlag"), rs.getString("updatedForSama"),
                        rs.getString("relationshipManager"), rs.getString("generalMemo"),
                        rs.getString("marketingMemo"), rs.getString("accFreezingGracePeriod")})
                .stream().findFirst()
                .map(c -> {
                    String[] home = homeAddress(params);
                    String[] acct = acctFacilityRows(c[1], c[2], c[3]);
                    return new JuristicAccountInfo(c[0],
                            home[0], home[1], home[2], home[3], home[4], home[5],
                            home[6], home[7], home[8], home[9], home[10], home[11],
                            acct[0], acct[1], acct[2], acct[3], acct[4],
                            acct[5], acct[6], acct[7], acct[8],
                            acct[9], acct[10], acct[11], acct[12], acct[13],
                            c[4], c[5], c[6], c[7],
                            c[8], c[9], c[10], c[11]);
                });
    }

    /**
     * frmJuristicAccountInfo home-country address: the legacy fills
     * homeAddress1..homeEmail exclusively from the staddrtab
     * addressType "01" (abroad) record with addressNo "0000"
     * (cbjuristic.c:3263-3282; the addressNo filter is the continue at
     * :3236); the block stays blank when no such row exists. The
     * stcusttab address columns are the LOCAL address
     * (cbjuristic.c:3058-3078, overlaid from type "00" at :3239-3261)
     * and must not be shown here.
     */
    private String[] homeAddress(Map<String, Object> params) {
        String[] blank = new String[12];
        Arrays.fill(blank, "");
        return jdbc.query("""
                SELECT address1, address2, poBox, zipCode, cityName, country,
                       telOffNo, telHomeNo, faxNo, mobileNo, pagerNo, eMail
                FROM   staddrtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  addressType = '01' AND addressNo = '0000'
                """,
                params,
                (rs, i) -> new String[] {
                        rs.getString("address1"), rs.getString("address2"),
                        rs.getString("poBox"), rs.getString("zipCode"),
                        rs.getString("cityName"), rs.getString("country"),
                        rs.getString("telOffNo"), rs.getString("telHomeNo"),
                        rs.getString("faxNo"), rs.getString("mobileNo"),
                        rs.getString("pagerNo"), rs.getString("eMail")})
                .stream().findFirst().orElse(blank);
    }

    /**
     * getAcctInfo port (cbothers.c:7183-7306; the juristic caller seeds
     * the key with the customer's branchCode + createdUserId +
     * createdDateTime, cbjuristic.c:3304-3313). The per-year acclog
     * files collapse to the stacclog view. The 14-char account number is
     * currency(2)+ledger(3)+…: ledger "008" fills the current row, "009"
     * the saving row, anything else the other row; later rows overwrite
     * earlier ones like the legacy strncpy. The C's 11-char info string
     * is currency(2)+ledger(3)+accStatus(2)+statementFreq(2)+
     * checkBook(1)+droppedAcc(1); droppedAcc has no slot in the enquiry
     * model, and the flag slots carry "1" for row-found (the screen's
     * facility check-box). Returns the 14 facility slots in
     * JuristicAccountInfo order; blanks on any failure — the C ignores
     * acclog open errors too.
     */
    private String[] acctFacilityRows(String branchCode, String createdUserId, String createdDateTime) {
        String[] slots = new String[14];
        Arrays.fill(slots, "");
        try {
            List<String[]> rows = jdbc.query("""
                    SELECT accNo, accStatus, statementFreq, checkBook, droppedAcc
                    FROM   stacclog
                    WHERE  BankingDate = :bankingDate
                      AND  branchCode = :branchCode
                      AND  userId = :userId
                      AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
                    """,
                    Map.of("bankingDate", bankingDate.bankingDate(),
                            "branchCode", branchCode == null ? "" : branchCode,
                            "userId", createdUserId == null ? "" : createdUserId,
                            "dateTime", createdDateTime == null ? "" : createdDateTime,
                            "dateTimeIso", BmForms.bmToIso(
                                    createdDateTime == null ? "" : createdDateTime)),
                    (rs, i) -> new String[] {
                            rs.getString("accNo"), rs.getString("accStatus"),
                            rs.getString("statementFreq"), rs.getString("checkBook"),
                            rs.getString("droppedAcc")});
            for (String[] r : rows) {
                String accNo = r[0] == null ? "" : r[0];
                String currency = accNo.length() >= 2 ? accNo.substring(0, 2) : "";
                String ledger = accNo.length() >= 5 ? accNo.substring(2, 5) : "";
                String status = trim(r[1]);
                String stmtFreq = trim(r[2]);
                String chequeBook = trim(r[3]);
                if ("008".equals(ledger)) {         // current account (cbothers.c:7244/7287)
                    slots[0] = "1";
                    slots[1] = currency;
                    slots[2] = stmtFreq;
                    slots[3] = chequeBook;
                    slots[4] = status;
                } else if ("009".equals(ledger)) {  // savings account (cbothers.c:7250/7292)
                    slots[5] = "1";
                    slots[6] = currency;
                    slots[7] = stmtFreq;
                    slots[8] = status;
                } else {                            // other account (cbothers.c:7256/7297)
                    slots[9] = ledger;
                    slots[10] = currency;
                    slots[11] = stmtFreq;
                    slots[12] = chequeBook;
                    slots[13] = status;
                }
            }
        } catch (DataAccessException e) {
            log.warn("stacclog unavailable; juristic account-facility rows left blank", e);
            Arrays.fill(slots, "");
        }
        return slots;
    }

    // ------------------------------------------------------------------
    // §22 — related parties. The archival tables carry every entry-record
    // field directly (proxy / joint / share-holding columns included), so
    // no stidtab/staddrtab detail joins are needed for these list rows.
    // Note: unlike the stcusttab a2ndName/a3rdName spelling, these tables
    // use aSecondName/aThirdName (schema files win over the spec).
    // ------------------------------------------------------------------

    @Override
    public List<HeirEntry> heirs(String custNo) {
        return jdbc.query("""
                SELECT heirNo, heirType, idType, idNo, proxyNo,
                       proxyIssueDateH, proxyIssueDateG, activeStatus, branchCode,
                       COALESCE(NULLIF(TRIM(aShortName), ''), eShortName) AS shortName
                FROM   stheirtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                ORDER  BY heirNo
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> new HeirEntry(
                        rs.getString("heirNo"), rs.getString("heirType"),
                        rs.getString("shortName"), rs.getString("idType"), rs.getString("idNo"),
                        rs.getString("proxyNo"),
                        BmForms.actualDate(rs.getString("proxyIssueDateH")),
                        BmForms.actualDate(rs.getString("proxyIssueDateG")),
                        rs.getString("activeStatus"), rs.getString("branchCode")));
    }

    @Override
    public List<JointHolderEntry> jointHolders(String custNo) {
        // §22: joint holders pick the short name by the joint customer's
        // preferredLang (not the Arabic-first COALESCE) — done in Java.
        return jdbc.query("""
                SELECT jointCustNo, aShortName, eShortName, preferredLang,
                       idType, idNo, nationality, mobileNo, jointOpenDate,
                       activeStatus, branchCode
                FROM   stjointtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                ORDER  BY jointCustNo
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> {
                    String shortName = prefersArabic(rs.getString("preferredLang"))
                            ? firstNonBlank(rs.getString("aShortName"), rs.getString("eShortName"))
                            : firstNonBlank(rs.getString("eShortName"), rs.getString("aShortName"));
                    return new JointHolderEntry(
                            rs.getString("jointCustNo"), shortName,
                            rs.getString("idType"), rs.getString("idNo"),
                            rs.getString("nationality"), rs.getString("mobileNo"),
                            BmForms.actualDate(rs.getString("jointOpenDate")),
                            rs.getString("activeStatus"), rs.getString("branchCode"));
                });
    }

    @Override
    public List<ReferenceEntry> references(String custNo) {
        return jdbc.query("""
                SELECT referenceNo, referenceType, referenceReqdFor,
                       idType, idNo, activeStatus, branchCode,
                       COALESCE(NULLIF(TRIM(aShortName), ''), eShortName) AS shortName
                FROM   stcreftab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                ORDER  BY referenceNo
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> new ReferenceEntry(
                        rs.getString("referenceNo"), rs.getString("referenceType"),
                        rs.getString("referenceReqdFor"), rs.getString("shortName"),
                        rs.getString("idType"), rs.getString("idNo"),
                        rs.getString("activeStatus"), rs.getString("branchCode")));
    }

    /**
     * The owner form's detail panel — 54 controls the grid does not carry.
     *
     * <p>Three reads, keyed as the C keys them (cbsama.c:2302-2450):
     * stowntab on custNo + ownerNo; stidtab on custNo + the owner's own idType
     * and idNo with {@code idCategory = 'W'}, which is the OWNER bucket ('C' is
     * the customer's own documents); and staddrtab on custNo where
     * {@code addressNo} equals the ownerNo — type '03' local, '04' home. The C
     * walks the customer's address rows and keeps those two; here they are two
     * predicates on one read, which is the same set.
     *
     * <p>Both addresses are optional: an owner with neither still returns, with
     * empty blocks, exactly as the legacy form shows empty frames.
     */
    @Override
    public Optional<OwnerDetail> ownerDetail(String custNo, String ownerNo) {
        Map<String, Object> params = Map.of(
                "bankingDate", bankingDate.bankingDate(),
                "custNo", padCust(custNo),
                "ownerNo", ownerNo.trim());

        List<Object[]> owner = jdbc.query("""
                SELECT ownerNo, ownerType, ownerEnabled, branchCode, idType, idNo,
                       shareHoldingPerc, parentCompanyName,
                       aFirstName, aSecondName, aThirdName, aLastName, aShortName,
                       eFirstName, eSecondName, eThirdName, eLastName, eShortName
                FROM   stowntab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  ownerNo = :ownerNo
                FETCH FIRST 1 ROWS ONLY
                """, params, (rs, i) -> new Object[] {
                        trim(rs.getString("ownerNo")), trim(rs.getString("ownerType")),
                        trim(rs.getString("ownerEnabled")), trim(rs.getString("branchCode")),
                        trim(rs.getString("idType")), trim(rs.getString("idNo")),
                        trim(rs.getString("shareHoldingPerc")),
                        trim(rs.getString("parentCompanyName")),
                        trim(rs.getString("aFirstName")), trim(rs.getString("aSecondName")),
                        trim(rs.getString("aThirdName")), trim(rs.getString("aLastName")),
                        trim(rs.getString("aShortName")),
                        trim(rs.getString("eFirstName")), trim(rs.getString("eSecondName")),
                        trim(rs.getString("eThirdName")), trim(rs.getString("eLastName")),
                        trim(rs.getString("eShortName"))});
        if (owner.isEmpty()) {
            return Optional.empty();
        }
        Object[] o = owner.get(0);

        String[] id = partyIdRow(params, "W", (String) o[4], (String) o[5]);
        Map<String, OwnerDetail.Address> addresses = partyAddresses(new HashMap<>(Map.of(
                "bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo),
                "partyNo", ownerNo.trim(), "addressTypes", List.of("03", "04"))));

        return Optional.of(new OwnerDetail(
                trim(custNo), (String) o[0], (String) o[1], (String) o[2], (String) o[3],
                (String) o[6], (String) o[7],
                (String) o[8], (String) o[9], (String) o[10], (String) o[11], (String) o[12],
                (String) o[13], (String) o[14], (String) o[15], (String) o[16], (String) o[17],
                (String) o[4], (String) o[5],
                id[0], id[1], id[2], id[3], id[4], id[5],
                addresses.getOrDefault("03", OwnerDetail.Address.empty()),
                addresses.getOrDefault("04", OwnerDetail.Address.empty())));
    }

    /**
     * The Joint Holders panel — frmIndividualJoint's grid double-click
     * (fetchJointDetailInfo). One point read: stjointtab keeps a joint holder
     * as a near-complete customer record, so unlike the owner, reference and
     * heir panels there is no ID row or address row to fetch alongside.
     */
    @Override
    public Optional<JointHolderDetail> jointHolderDetail(String custNo, String jointCustNo) {
        List<JointHolderDetail> rows = jdbc.query("""
                SELECT jointCustNo, branchCode, activeStatus, jointOpenDate,
                       aFirstName, a2ndName, a3rdName, aLastName, aShortName,
                       eFirstName, e2ndName, e3rdName, eLastName, eShortName,
                       idType, idNo, idIssuedAt, idDateType,
                       idIssueDateH, idIssueDateG, idExpiryDateH, idExpiryDateG,
                       preferredLang, nationality, titleCode,
                       dobDateType, dobDateH, dobDateG, sexCode, vipCode,
                       marritalStatus, noOfDependents, residentStatus, businessType,
                       address1, address2, poBox, cityName, zipCode, country,
                       addressType, gprsNo, unitNo,
                       telOffAreaCode, telOffNo, telOffExt,
                       telHomeAreaCode, telHomeNo, telHomeExt,
                       faxAreaCode, faxNo, faxExt, mobileNo, pagerNo, eMail,
                       educationCode, professionCode, positionCode, monthlyIncome,
                       ownerShip, segmenation, employerName, department,
                       employerPoBox, employerCity, employerZipCode
                FROM   stjointtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  jointCustNo = :jointCustNo
                FETCH FIRST 1 ROWS ONLY
                """,
                Map.of("bankingDate", bankingDate.bankingDate(),
                        "custNo", padCust(custNo), "jointCustNo", jointCustNo.trim()),
                (rs, i) -> new JointHolderDetail(
                        trim(custNo),
                        trim(rs.getString("jointCustNo")),
                        trim(rs.getString("branchCode")),
                        trim(rs.getString("activeStatus")),
                        BmForms.actualDate(rs.getString("jointOpenDate")),
                        trim(rs.getString("aFirstName")),
                        trim(rs.getString("a2ndName")),
                        trim(rs.getString("a3rdName")),
                        trim(rs.getString("aLastName")),
                        trim(rs.getString("aShortName")),
                        trim(rs.getString("eFirstName")),
                        trim(rs.getString("e2ndName")),
                        trim(rs.getString("e3rdName")),
                        trim(rs.getString("eLastName")),
                        trim(rs.getString("eShortName")),
                        trim(rs.getString("idType")),
                        trim(rs.getString("idNo")),
                        trim(rs.getString("idIssuedAt")),
                        trim(rs.getString("idDateType")),
                        BmForms.actualDate(rs.getString("idIssueDateH")),
                        BmForms.actualDate(rs.getString("idIssueDateG")),
                        BmForms.actualDate(rs.getString("idExpiryDateH")),
                        BmForms.actualDate(rs.getString("idExpiryDateG")),
                        trim(rs.getString("preferredLang")),
                        trim(rs.getString("nationality")),
                        trim(rs.getString("titleCode")),
                        trim(rs.getString("dobDateType")),
                        BmForms.actualDate(rs.getString("dobDateH")),
                        BmForms.actualDate(rs.getString("dobDateG")),
                        trim(rs.getString("sexCode")),
                        trim(rs.getString("vipCode")),
                        trim(rs.getString("marritalStatus")),
                        trim(rs.getString("noOfDependents")),
                        trim(rs.getString("residentStatus")),
                        trim(rs.getString("businessType")),
                        trim(rs.getString("address1")),
                        trim(rs.getString("address2")),
                        trim(rs.getString("poBox")),
                        trim(rs.getString("cityName")),
                        trim(rs.getString("zipCode")),
                        trim(rs.getString("country")),
                        trim(rs.getString("addressType")),
                        trim(rs.getString("gprsNo")),
                        trim(rs.getString("unitNo")),
                        trim(rs.getString("telOffAreaCode")),
                        trim(rs.getString("telOffNo")),
                        trim(rs.getString("telOffExt")),
                        trim(rs.getString("telHomeAreaCode")),
                        trim(rs.getString("telHomeNo")),
                        trim(rs.getString("telHomeExt")),
                        trim(rs.getString("faxAreaCode")),
                        trim(rs.getString("faxNo")),
                        trim(rs.getString("faxExt")),
                        trim(rs.getString("mobileNo")),
                        trim(rs.getString("pagerNo")),
                        trim(rs.getString("eMail")),
                        trim(rs.getString("educationCode")),
                        trim(rs.getString("professionCode")),
                        trim(rs.getString("positionCode")),
                        trim(rs.getString("monthlyIncome")),
                        trim(rs.getString("ownerShip")),
                        trim(rs.getString("segmenation")),
                        trim(rs.getString("employerName")),
                        trim(rs.getString("department")),
                        trim(rs.getString("employerPoBox")),
                        trim(rs.getString("employerCity")),
                        trim(rs.getString("employerZipCode"))));
        return rows.stream().findFirst();
    }

    /**
     * The Reference / Legal Representative panel — frmIndividualSaudi2's
     * double-click (referenceInfoGrid_DblClick :2722, readReferenceTabInfo
     * cbsama.c:3400). stcreftab plus the 'R' ID row and the '02' address.
     */
    @Override
    public Optional<PartyDetail> referenceDetail(String custNo, String referenceNo) {
        return partyDetail("reference", custNo, referenceNo, """
                SELECT referenceNo AS partyNo, referenceType AS partyType,
                       referenceReqdFor, activeStatus, disabledDate, branchCode,
                       idType, idNo,
                       aFirstName, aSecondName, aThirdName, aLastName, aShortName,
                       eFirstName, eSecondName, eThirdName, eLastName, eShortName,
                       '' AS proxyNo, '' AS proxyDateType,
                       '' AS proxyIssueDateH, '' AS proxyIssueDateG
                FROM   stcreftab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  referenceNo = :partyNo
                FETCH FIRST 1 ROWS ONLY
                """, "R", "02");
    }

    /**
     * The Heirs / Proxy panel — frmIndividualHeirs' double-click
     * (heirInfoGrid_DblClick :2807). stheirtab plus the 'H' ID row and the '05'
     * address. The proxy block is stheirtab's own, not an ID row.
     */
    @Override
    public Optional<PartyDetail> heirDetail(String custNo, String heirNo) {
        return partyDetail("heir", custNo, heirNo, """
                SELECT heirNo AS partyNo, heirType AS partyType,
                       '' AS referenceReqdFor, activeStatus, disabledDate, branchCode,
                       idType, idNo,
                       aFirstName, aSecondName, aThirdName, aLastName, aShortName,
                       eFirstName, eSecondName, eThirdName, eLastName, eShortName,
                       proxyNo, proxyDateType, proxyIssueDateH, proxyIssueDateG
                FROM   stheirtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  heirNo = :partyNo
                FETCH FIRST 1 ROWS ONLY
                """, "H", "05");
    }

    /**
     * The shared half of the two panels: read the party row, then its ID row
     * and its address. Only the table, the ID bucket and the address type
     * differ, which is exactly what the C varies between
     * readReferenceTabInfo and the heir path.
     */
    private Optional<PartyDetail> partyDetail(String kind, String custNo, String partyNo,
            String sql, String idCategory, String addressType) {
        Map<String, Object> params = new HashMap<>(Map.of(
                "bankingDate", bankingDate.bankingDate(),
                "custNo", padCust(custNo),
                "partyNo", partyNo.trim()));

        List<String[]> rows = jdbc.query(sql, params, (rs, i) -> new String[] {
                trim(rs.getString("partyNo")), trim(rs.getString("partyType")),
                trim(rs.getString("referenceReqdFor")), trim(rs.getString("activeStatus")),
                BmForms.actualDate(rs.getString("disabledDate")), trim(rs.getString("branchCode")),
                trim(rs.getString("idType")), trim(rs.getString("idNo")),
                trim(rs.getString("aFirstName")), trim(rs.getString("aSecondName")),
                trim(rs.getString("aThirdName")), trim(rs.getString("aLastName")),
                trim(rs.getString("aShortName")),
                trim(rs.getString("eFirstName")), trim(rs.getString("eSecondName")),
                trim(rs.getString("eThirdName")), trim(rs.getString("eLastName")),
                trim(rs.getString("eShortName")),
                trim(rs.getString("proxyNo")), trim(rs.getString("proxyDateType")),
                BmForms.actualDate(rs.getString("proxyIssueDateH")),
                BmForms.actualDate(rs.getString("proxyIssueDateG"))});
        if (rows.isEmpty()) {
            return Optional.empty();
        }
        String[] r = rows.get(0);

        String[] id = partyIdRow(params, idCategory, r[6], r[7]);
        Map<String, OwnerDetail.Address> addresses = partyAddresses(new HashMap<>(Map.of(
                "bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo),
                "partyNo", partyNo.trim(), "addressTypes", List.of(addressType))));

        return Optional.of(new PartyDetail(
                kind, trim(custNo), r[0], r[1], r[3], r[4], r[5],
                r[8], r[9], r[10], r[11], r[12], r[13], r[14], r[15], r[16], r[17],
                r[6], r[7], id[0], id[1], id[2], id[3], id[4], id[5],
                r[2], r[18], r[19], r[20], r[21],
                addresses.getOrDefault(addressType, OwnerDetail.Address.empty())));
    }

    /**
     * One party's stidtab row. The idCategory letter is the bucket: 'W' owners
     * (cbsama.c:2356), 'R' references (:3400), 'H' heirs (:1632), against the
     * customer's own 'C' documents.
     */
    private String[] partyIdRow(Map<String, Object> base, String idCategory,
            String idType, String idNo) {
        Map<String, Object> params = new HashMap<>(base);
        params.put("idType", idType);
        params.put("idNo", idNo);
        params.put("idCategory", idCategory);
        List<String[]> rows = jdbc.query("""
                SELECT idIssuedAt, idDateType, idIssueDateH, idIssueDateG,
                       idExpiryDateH, idExpiryDateG
                FROM   stidtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  idCategory = :idCategory
                  AND  idType = :idType
                  AND  idNo = :idNo
                FETCH FIRST 1 ROWS ONLY
                """, params, (rs, i) -> new String[] {
                        trim(rs.getString("idIssuedAt")), trim(rs.getString("idDateType")),
                        BmForms.actualDate(rs.getString("idIssueDateH")),
                        BmForms.actualDate(rs.getString("idIssueDateG")),
                        BmForms.actualDate(rs.getString("idExpiryDateH")),
                        BmForms.actualDate(rs.getString("idExpiryDateG"))});
        return rows.isEmpty() ? new String[] {"", "", "", "", "", ""} : rows.get(0);
    }

    /**
     * staddrtab rows hanging off a party number rather than the customer.
     *
     * <p>Every related party's address lives in the CUSTOMER's address file,
     * keyed by {@code addressNo} = that party's number, with the type saying
     * which party family it belongs to: '02' references, '03'/'04' owner local
     * and home, '05' heirs (cbsama.c:1792, 2380, 2421, 3422).
     */
    private Map<String, OwnerDetail.Address> partyAddresses(Map<String, Object> params) {
        Map<String, OwnerDetail.Address> byType = new HashMap<>();
        jdbc.query("""
                SELECT addressType, address1, address2, poBox, cityName, zipCode,
                       country, addrType, unitNo,
                       telOffAreaCode, telOffNo, telOffExt,
                       telHomeAreaCode, telHomeNo, telHomeExt,
                       faxAreaCode, faxNo, faxExt, mobileNo, pagerNo, eMail
                FROM   staddrtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  addressNo = :partyNo
                  AND  addressType IN (:addressTypes)
                """, params, (rs, i) -> {
                    byType.put(trim(rs.getString("addressType")), new OwnerDetail.Address(
                            trim(rs.getString("address1")), trim(rs.getString("address2")),
                            trim(rs.getString("poBox")), trim(rs.getString("cityName")),
                            trim(rs.getString("zipCode")), trim(rs.getString("country")),
                            trim(rs.getString("addrType")), trim(rs.getString("unitNo")),
                            trim(rs.getString("telOffAreaCode")), trim(rs.getString("telOffNo")),
                            trim(rs.getString("telOffExt")),
                            trim(rs.getString("telHomeAreaCode")), trim(rs.getString("telHomeNo")),
                            trim(rs.getString("telHomeExt")),
                            trim(rs.getString("faxAreaCode")), trim(rs.getString("faxNo")),
                            trim(rs.getString("faxExt")), trim(rs.getString("mobileNo")),
                            trim(rs.getString("pagerNo")), trim(rs.getString("eMail"))));
                    return null;
                });
        return byType;
    }

    @Override
    public List<OwnerEntry> owners(String custNo) {
        return jdbc.query("""
                SELECT ownerNo, ownerType, idType, idNo, parentCompanyName,
                       shareHoldingPerc, ownerEnabled, branchCode,
                       COALESCE(NULLIF(TRIM(aShortName), ''), eShortName) AS shortName
                FROM   stowntab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                ORDER  BY ownerNo
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> new OwnerEntry(
                        rs.getString("ownerNo"), rs.getString("ownerType"),
                        rs.getString("shortName"), rs.getString("idType"), rs.getString("idNo"),
                        rs.getString("parentCompanyName"), rs.getString("shareHoldingPerc"),
                        rs.getString("ownerEnabled"), rs.getString("branchCode")));
    }

    // ------------------------------------------------------------------
    // Helpers (legacy conventions kept out of the SQL).
    // ------------------------------------------------------------------

    private static boolean hasText(String s) {
        return s != null && !s.isBlank();
    }

    @Override
    public Map<String, String> acctInfo(String custNo) {
        // Page-2 enquiry fields for BOTH individual profiles — stcusttab
        // customer attributes, plus the account-facility rows. Keys match the
        // screens; codes are raw (the UI maps them via /api/codes).
        //
        // The facility rows are here because frmIndividualOthersAcctInfo has
        // nothing else: its whole form is the accounts block, card delivery and
        // signature nature. Card DELIVERY stays out — which card to issue and
        // where to post it is a create-time instruction with no archival
        // counterpart, and issued cards already have their own screens off
        // stcardtab. The accounts block is not create-only in the same way:
        // getAcctInfo reads it back from the account log, and
        // frmJuristicAccountInfo already renders exactly these fields as
        // enquiry data.
        //
        // branchCode / createdUserId / createdDateTime are selected only to key
        // acctFacilityRows — the same three the juristic caller seeds it with
        // (cbjuristic.c:3304-3313) — and are not returned.
        // The Others profile carries a page BETWEEN these two — frmIndividualOthers2,
        // "Customers Maintenance Page 2 - For Other Individuals" — whose fields come
        // from the same customer row plus two side reads (see homeAddress/idRows
        // below). They ride on this call rather than a third endpoint because the C
        // builds the whole reply in ONE pass (processIndividualOthersDetails,
        // cbothers.c:2860-3200) and the Saudi page 2 already asks for the overlap;
        // splitting it would mean two round trips for one legacy screen. The Saudi
        // screen simply renders fewer of the keys.
        List<Map<String, String>> rows = jdbc.query("""
                SELECT educationCode, professionCode, positionCode, monthlyIncome,
                       segmentation, employerName, employerPoBox, employerCity,
                       employerZipCode, packageAcc, signatureNature, custAdviceFlag,
                       updatedForSama, relationshipManager, generalMemo, marketingMemo,
                       accFreezingGracePeriod, department, ownerShip, singleJointAcc,
                       excludeFromAtmFees, excludeFromMinBalFees, pkgStmtFreqOverride,
                       interGroupAccNo, specialRefNo,
                       branchCode, createdUserId, createdDateTime
                FROM   stcusttab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                FETCH FIRST 1 ROWS ONLY
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> {
                    Map<String, String> d = new LinkedHashMap<>();
                    d.put("education", trim(rs.getString("educationCode")));
                    d.put("profession", trim(rs.getString("professionCode")));
                    d.put("position", trim(rs.getString("positionCode")));
                    d.put("monthlyIncome", trim(rs.getString("monthlyIncome")));
                    d.put("segmentation", trim(rs.getString("segmentation")));
                    d.put("employerName", trim(rs.getString("employerName")));
                    d.put("employerPoBox", trim(rs.getString("employerPoBox")));
                    d.put("employerCity", trim(rs.getString("employerCity")));
                    d.put("employerZipCode", trim(rs.getString("employerZipCode")));
                    d.put("packageAcc", trim(rs.getString("packageAcc")));
                    d.put("signatureNature", trim(rs.getString("signatureNature")));
                    d.put("custAdviceFlag", trim(rs.getString("custAdviceFlag")));
                    d.put("updatedForSama", trim(rs.getString("updatedForSama")));
                    d.put("relationshipManager", trim(rs.getString("relationshipManager")));
                    d.put("generalMemo", trim(rs.getString("generalMemo")));
                    d.put("marketingMemo", trim(rs.getString("marketingMemo")));
                    d.put("freezingGracePeriod", trim(rs.getString("accFreezingGracePeriod")));
                    // frmIndividualOthers2 additions. ownerShip is SIX flags packed
                    // into one string — rented house / own house / company
                    // accommodation / rented car / own car / company transport, read
                    // by position (globalFunctions.bas:6455-6485) — so it is passed
                    // through raw and split in the UI, where the six labels live.
                    d.put("department", trim(rs.getString("department")));
                    d.put("ownerShip", trim(rs.getString("ownerShip")));
                    d.put("singleJointAcc", trim(rs.getString("singleJointAcc")));
                    d.put("excludeFromAtmFees", trim(rs.getString("excludeFromAtmFees")));
                    d.put("excludeFromMinBalFees", trim(rs.getString("excludeFromMinBalFees")));
                    d.put("pkgStmtFreqOverride", trim(rs.getString("pkgStmtFreqOverride")));
                    d.put("interGroupAccNo", trim(rs.getString("interGroupAccNo")));
                    d.put("specialRefNo", trim(rs.getString("specialRefNo")));
                    String[] f = acctFacilityRows(rs.getString("branchCode"),
                            rs.getString("createdUserId"), rs.getString("createdDateTime"));
                    d.put("currentAcFlag", f[0]);
                    d.put("currentAcCurrency", f[1]);
                    d.put("currentAcStmtFreq", f[2]);
                    d.put("currentAcChequeBook", f[3]);
                    d.put("currentAcStatus", f[4]);
                    d.put("savingAcFlag", f[5]);
                    d.put("savingAcCurrency", f[6]);
                    d.put("savingAcStmtFreq", f[7]);
                    d.put("savingAcStatus", f[8]);
                    d.put("otherAcLedger", f[9]);
                    d.put("otherAcCurrency", f[10]);
                    d.put("otherAcStmtFreq", f[11]);
                    d.put("otherAcChequeBook", f[12]);
                    d.put("otherAcStatus", f[13]);
                    return d;
                });
        if (rows.isEmpty()) {
            return Map.of();
        }
        Map<String, String> info = new LinkedHashMap<>(rows.get(0));
        info.putAll(homeCountryAddress(custNo));
        info.putAll(identityBlocks(custNo));
        return info;
    }

    /**
     * The "Home Country Address" frame on frmIndividualOthers2 — staddrtab's
     * addressType '01' row.
     *
     * <p>The C walks the customer's staddrtab rows and keeps exactly two:
     * '00' is the main/local address (already on page 1 of the profile) and
     * '01' is the "customer abroad/home address" that fills this frame; every
     * other addressType is skipped outright (cbothers.c:3112-3164). So this is
     * one point read on '01' rather than a join — an expatriate with no abroad
     * address simply has no such row, and the frame comes back empty, which is
     * what the legacy shows too.
     *
     * <p>{@code addressNo = '0000'} is part of that filter and not optional:
     * the C skips every row whose addressNo is not "0000" BEFORE it switches on
     * the type ({@code if (strncmp(addrTabRec.addressNo, "0000", 4)) continue;},
     * cbothers.c:3117). addressNo is key part 4 and numbers the PARTY the row
     * belongs to — "0000" the account holder, "0001"+ the owners, heirs and
     * references hanging off the same custNo. Without it this read is
     * {@code FETCH FIRST 1 ROWS ONLY} over an unordered set and can return a
     * related party's abroad address — or a sparsely filled one, which is how
     * it shows up: Home Address, Phone (Res.) and Country blank on a customer
     * who demonstrably has them. The juristic twin has always carried the
     * filter (see {@code juristicAccountInfo}); this one had not.
     */
    private Map<String, String> homeCountryAddress(String custNo) {
        List<Map<String, String>> rows = jdbc.query("""
                SELECT address1, address2, poBox, cityName, zipCode, country,
                       telOffAreaCode, telOffNo, telOffExt,
                       telHomeAreaCode, telHomeNo, telHomeExt,
                       faxAreaCode, faxNo, faxExt, mobileNo, pagerNo, eMail
                FROM   staddrtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  addressType = '01' AND addressNo = '0000'
                FETCH FIRST 1 ROWS ONLY
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> {
                    Map<String, String> d = new LinkedHashMap<>();
                    d.put("homeAddress1", trim(rs.getString("address1")));
                    d.put("homeAddress2", trim(rs.getString("address2")));
                    d.put("homePoBox", trim(rs.getString("poBox")));
                    d.put("homeCityName", trim(rs.getString("cityName")));
                    d.put("homeZipCode", trim(rs.getString("zipCode")));
                    d.put("homeCountry", trim(rs.getString("country")));
                    d.put("homeTelOffAreaCode", trim(rs.getString("telOffAreaCode")));
                    d.put("homeTelOffNo", trim(rs.getString("telOffNo")));
                    d.put("homeTelOffExt", trim(rs.getString("telOffExt")));
                    d.put("homeTelHomeAreaCode", trim(rs.getString("telHomeAreaCode")));
                    d.put("homeTelHomeNo", trim(rs.getString("telHomeNo")));
                    d.put("homeTelHomeExt", trim(rs.getString("telHomeExt")));
                    d.put("homeFaxAreaCode", trim(rs.getString("faxAreaCode")));
                    d.put("homeFaxNo", trim(rs.getString("faxNo")));
                    d.put("homeFaxExt", trim(rs.getString("faxExt")));
                    d.put("homeMobileNo", trim(rs.getString("mobileNo")));
                    d.put("homePagerNo", trim(rs.getString("pagerNo")));
                    d.put("homeEmail", trim(rs.getString("eMail")));
                    return d;
                });
        return rows.isEmpty() ? Map.of() : rows.get(0);
    }

    /**
     * The Home Country ID, SAMA authorisation and approval-document frames.
     *
     * <p>All three are stidtab ID ROWS, not customer columns — the C loops the
     * customer's stidtab rows and switches on idType (cbothers.c:3025-3060):
     * <ul>
     *   <li>{@code 'M'} home country id → number, date type, issue and expiry</li>
     *   <li>{@code 'S'} SAMA authorisation → number, date type, and the ISSUE
     *       date as the approval date (there is no separate approval-date
     *       column; the C reads idIssueDateH/G)</li>
     *   <li>{@code 'A'} approval document → number, date type, issue, expiry,
     *       and {@code idRefName} as the approver's name</li>
     * </ul>
     * stcusttab also carries {@code homeCountryId}, {@code samaAuthNo} and
     * {@code approvalRefNo}, and taking them from there was the obvious
     * shortcut — but those are single denormalised copies with NO dates beside
     * them, and the dates are half of each frame. The ID rows are the C's
     * source, so they are the source here.
     *
     * <p>Both date calendars are returned as stored (H = Hijri, G = Gregorian);
     * {@code *DateType} says which one the operator entered ('0' Hijri), exactly
     * as the form's radio pair reports it.
     */
    private Map<String, String> identityBlocks(String custNo) {
        Map<String, String> out = new LinkedHashMap<>();
        jdbc.query("""
                SELECT idType, idNo, idDateType, idIssueDateH, idIssueDateG,
                       idExpiryDateH, idExpiryDateG, idRefName
                FROM   stidtab
                WHERE  BankingDate = :bankingDate
                  AND  custNo = :custNo
                  AND  idCategory = 'C'
                  AND  idType IN ('M', 'S', 'A')
                """,
                Map.of("bankingDate", bankingDate.bankingDate(), "custNo", padCust(custNo)),
                (rs, i) -> {
                    String type = trim(rs.getString("idType"));
                    switch (type) {
                        case "M" -> {
                            out.put("homeCountryId", trim(rs.getString("idNo")));
                            out.put("homeCountryIdDateType", trim(rs.getString("idDateType")));
                            out.put("homeCountryIdIssueDateH", trim(rs.getString("idIssueDateH")));
                            out.put("homeCountryIdIssueDateG", trim(rs.getString("idIssueDateG")));
                            out.put("homeCountryIdExpiryDateH", trim(rs.getString("idExpiryDateH")));
                            out.put("homeCountryIdExpiryDateG", trim(rs.getString("idExpiryDateG")));
                        }
                        case "S" -> {
                            out.put("samaAuthNo", trim(rs.getString("idNo")));
                            out.put("samaAuthDateType", trim(rs.getString("idDateType")));
                            out.put("samaAuthDateH", trim(rs.getString("idIssueDateH")));
                            out.put("samaAuthDateG", trim(rs.getString("idIssueDateG")));
                        }
                        case "A" -> {
                            out.put("approvalRefNo", trim(rs.getString("idNo")));
                            out.put("appDateType", trim(rs.getString("idDateType")));
                            out.put("appIssueDateH", trim(rs.getString("idIssueDateH")));
                            out.put("appIssueDateG", trim(rs.getString("idIssueDateG")));
                            out.put("appExpiryDateH", trim(rs.getString("idExpiryDateH")));
                            out.put("appExpiryDateG", trim(rs.getString("idExpiryDateG")));
                            out.put("appRefName", trim(rs.getString("idRefName")));
                        }
                        default -> { }
                    }
                    return null;
                });
        return out;
    }

    @Override
    public EssentialDocuments documents(String custNo, String asOfDateTime) {
        // The customer's own row first: it carries BOTH the SAMA category that
        // selects the required list AND the documents the customer actually
        // supplied. The legacy reads all three off the same record — the C
        // server ships custTabRec.documentsSupplied / .documentOther in the
        // detail message (cbothers.c:3168-3169) and the form renders them into
        // lstSelectedDoc / txtDocOthers (frmDocuments.frm:376-392).
        //
        // History mode reads the stcustlog snapshot instead, keyed the same way
        // profileAsOf keys it — the legacy's custHistoryAction path is fed by
        // processIndividual*PendingDetail off custLogRec (cbothers.c:3703-3704),
        // so the categories and the supplied set are both the ones in force at
        // that event, not today's.
        boolean asOf = asOfDateTime != null && !asOfDateTime.isBlank();
        Map<String, Object> params = new java.util.HashMap<>();
        params.put("bankingDate", bankingDate.bankingDate());
        params.put("custNo", padCust(custNo));
        String sql;
        if (asOf) {
            // Bound in both forms for the same reason profileAsOf does it: the
            // history grid may hand back a normalised ISO timestamp when the
            // view types datetime_bigdata as a timestamp rather than a string.
            params.put("dateTime", trim(asOfDateTime));
            params.put("dateTimeIso", BmForms.bmToIso(trim(asOfDateTime)));
            sql = """
                    SELECT samaMainCategory, samaSubCategory, documentsSupplied, documentOther
                    FROM   stcustlog
                    WHERE  BankingDate = :bankingDate
                      AND  custNo = :custNo
                      AND  (datetime_bigdata = :dateTime OR datetime_bigdata = :dateTimeIso)
                    FETCH FIRST 1 ROWS ONLY
                    """;
        } else {
            sql = """
                    SELECT samaMainCategory, samaSubCategory, documentsSupplied, documentOther
                    FROM   stcusttab
                    WHERE  BankingDate = :bankingDate
                      AND  custNo = :custNo
                    FETCH FIRST 1 ROWS ONLY
                    """;
        }
        List<String[]> cust = jdbc.query(sql, params,
                (rs, i) -> new String[] {trim(rs.getString("samaMainCategory")),
                        trim(rs.getString("samaSubCategory")),
                        rs.getString("documentsSupplied"),
                        trim(rs.getString("documentOther"))});
        if (cust.isEmpty()) {
            return EssentialDocuments.EMPTY;
        }
        String[] row = cust.get(0);
        List<String> supplied = EssentialDocuments.splitCodes(row[2]);

        // The required list for that category. Codes only — stctltabDC carries
        // the mapping and no name columns, and the legacy resolved names in a
        // documentinfo table in the client's LOCAL Access database
        // (frmDocuments.frm:337), which has no archival counterpart. The UI
        // resolves them against the stctltab 'DT' code set.
        List<List<String>> rows = jdbc.query("""
                SELECT documnetNo1, documnetNo2, documnetNo3, documnetNo4, documnetNo5,
                       documnetNo6, documnetNo7, documnetNo8, documnetNo9, documnetNo10,
                       documnetNo11, documnetNo12, documnetNo13, documnetNo14, documnetNo15,
                       documnetNo16, documnetNo17, documnetNo18, documnetNo19, documnetNo20
                FROM   stctltabDC
                WHERE  BankingDate = :bankingDate
                  AND  samaMainCategory = :main AND samaSubCategory = :sub
                FETCH FIRST 1 ROWS ONLY
                """,
                Map.of("bankingDate", bankingDate.bankingDate(),
                        "main", row[0], "sub", row[1]),
                (rs, i) -> {
                    List<String> docs = new java.util.ArrayList<>();
                    for (int n = 1; n <= 20; n++) {
                        String code = trim(rs.getString("documnetNo" + n));
                        if (code.isEmpty()) {
                            // The legacy walks a packed string and stops at the
                            // first blank triplet (frmDocuments.frm:331), so a
                            // gap ends the list rather than being skipped over.
                            break;
                        }
                        docs.add(code);
                    }
                    return docs;
                });
        return new EssentialDocuments(
                rows.isEmpty() ? List.of() : rows.get(0), supplied, row[3]);
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    /** Name searches are prefix scans on the trailing-space-trimmed input (§1). */
    private static String trimName(String s) {
        return s == null ? "" : s.stripTrailing();
    }

    /** Legacy Arabic-vs-English index choice: first character code > 127. */
    private static boolean isArabic(String s) {
        return !s.isEmpty() && s.codePointAt(0) > 127;
    }

    /** Customer numbers are 7-char zero-padded keys. */
    private static String padCust(String custNo) {
        String c = trim(custNo);
        return c.length() >= 7 ? c : "0".repeat(7 - c.length()) + c;
    }

    /** preferredLang: '0' = Arabic, '1' = English in the archival data
     *  (fixture convention; 'A' accepted defensively). */
    private static boolean prefersArabic(String lang) {
        String l = trim(lang);
        return "0".equals(l) || "A".equalsIgnoreCase(l);
    }

    /** Legacy custType: '0' = consumer, '1' = commercial, '2' = corporate
     *  (stlayout.h customerInfo custType comment). The C treats BOTH '1'
     *  and '2' as org-name customers — cbbranch.c:1888 tests
     *  custType != '1' && custType != '2' for the consumer branch.
     *  'C' accepted harmlessly for the fixtures (which use 'P'/'C'). */
    private static boolean isCorporate(String custType) {
        String t = trim(custType);
        return "1".equals(t) || "2".equals(t) || "C".equalsIgnoreCase(t);
    }

    private static String firstNonBlank(String preferred, String fallback) {
        String p = trim(preferred);
        return p.isEmpty() ? trim(fallback) : p;
    }

    /** stcustlog.bmUpdateStatus code → the legacy display label shown in
     *  the Pending Status grid column (mock/StatusBadge convention). */
    private static String statusLabel(String code) {
        return switch (code) {
            case "0" -> "0-Entered";
            case "1" -> "1-Pending with supervisor";
            case "2" -> "2-Pending with teller";
            case "3" -> "3-Rejected by the branch";
            case "9" -> "9-Update successful";
            default -> code;
        };
    }
}
